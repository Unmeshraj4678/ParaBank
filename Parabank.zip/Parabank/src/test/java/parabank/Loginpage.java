package parabank;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;



public class Loginpage  {
	public static void main(String[] args) throws InterruptedException {
		
		//open chrome
		System.setProperty("webdriver.chrome.driver", "E:\\Selenium\\chromedriver.exe" );
		WebDriver driver= new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
		//Enter Url
		
		driver.get("https://parabank.parasoft.com/parabank/index.htm");
		
		//user name
		Thread.sleep(5000);
		WebElement oUserName = driver.findElement(By.name("username"));
		oUserName.sendKeys("unmeshraj");
		
		//User password
		Thread.sleep(5000);
		WebElement oPassword = driver.findElement(By.name("password"));
		oPassword.sendKeys("Test12");
		
		//Submit
		Thread.sleep(5000);
		WebElement oSubmit =driver.findElement(By.xpath("//*[@id=\"loginPanel\"]/form/div[3]/input"));
		oSubmit.click();
		
		//validation-title
		String expected = "ParaBank | Accounts Overview";
		String actual = driver.getTitle();
		
		if (expected.equals(actual)) {
			System.out.println("Login Successfull.");
		}
		else{
			System.out.println("Login failed.");
			
		}
		
		
		
	}

}
