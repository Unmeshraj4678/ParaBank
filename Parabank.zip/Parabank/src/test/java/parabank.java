import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class parabank {
	WebDriver driver= null;
  @BeforeSuite
  public void BeforeSite() {
	  System.setProperty("webdriver.chrome.driver", "E:\\Selenium\\chromedriver.exe" );
	  
  }
  @BeforeMethod
  public void BeforeMethod() {
		//open chrome
	  WebDriver driver= new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().window().maximize();
  }
  @AfterMethod
  public void AfterMethod() {
	  driver.quit();
  }
  
@Test
  public void t_001_chech_url()  throws InterruptedException {

			//Enter Url
			
			driver.get("https://parabank.parasoft.com/parabank/index.htm");
			
			//validation-title
			String expected = "ParaBank | Login Page";
			String actual = driver.getTitle();
			
			if (expected.equals(actual)) {
				System.out.println("Url Successfull.");
			}
			else{
				System.out.println("Url failed.");
				
			}
			
}
  @Test
  public void t_002_Login_page()  throws InterruptedException {
	//user name
		Thread.sleep(5000);
		WebElement oUserName = driver.findElement(By.name("username"));
		oUserName.sendKeys("unmeshraj");
		
		//User password
		Thread.sleep(5000);
		WebElement oPassword = driver.findElement(By.name("password"));
		oPassword.sendKeys("Test12");
		
		//Submit
		Thread.sleep(5000);
		WebElement oSubmit =driver.findElement(By.xpath("//*[@id=\"loginPanel\"]/form/div[3]/input"));
		oSubmit.click();
		
		
	  
  }
}
